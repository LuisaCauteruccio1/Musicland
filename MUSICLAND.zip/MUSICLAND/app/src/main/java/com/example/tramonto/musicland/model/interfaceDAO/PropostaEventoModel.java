package com.example.tramonto.musicland.model.interfaceDAO;

import com.example.tramonto.musicland.model.pojo.PropostaEvento;

import java.util.ArrayList;

public interface PropostaEventoModel {

    public void doSave(PropostaEvento propostaEvento); //aggiungere eccezioni
    public int doUpdate(PropostaEvento propostaEvento);
    public void doDelete(PropostaEvento propostaEvento);
    public PropostaEvento doRetrieveByKey(int idEvento);
    public ArrayList<PropostaEvento> doRetrieveAll(String order);
}
