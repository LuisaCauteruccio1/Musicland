package com.example.tramonto.musicland.presenter;

import com.example.tramonto.musicland.manager.AmministrazionePiattaforma;
import com.example.tramonto.musicland.model.pojo.Evento;
import com.example.tramonto.musicland.model.pojo.PropostaEvento;
import com.example.tramonto.musicland.model.pojo.Utente;

import java.util.ArrayList;

public class PresenterAmministrazionePiattaforma implements AmministrazionePiattaforma {
    @Override
    public ArrayList<Utente> visualizzaListaUtenti() {
        return null;
    }

    @Override
    public boolean eliminaUtente(Utente utente) {
        return false;
    }

    @Override
    public ArrayList<PropostaEvento> visualizzaListaProposteEvento() {
        return null;
    }

    @Override
    public boolean eliminaPropostaEventoUtente(PropostaEvento propostaEvento) {
        return false;
    }

    @Override
    public ArrayList<Evento> visualizzaListaEventi() {
        return null;
    }

    @Override
    public boolean eliminaEventoUtente(Evento evento) {
        return false;
    }
}
