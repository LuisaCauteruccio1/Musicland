package com.example.tramonto.musicland.presenter;

import com.example.tramonto.musicland.manager.GestioneAutenticazione;
import com.example.tramonto.musicland.model.pojo.Utente;

public class PresenterAutenticazione implements GestioneAutenticazione {
    @Override
    public Utente login(String email, String password) {
        return null;
    }
}
