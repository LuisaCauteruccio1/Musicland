package com.example.tramonto.musicland.model.interfaceDAO;

import com.example.tramonto.musicland.model.pojo.Artista;
import com.example.tramonto.musicland.model.pojo.Evento;


import java.util.ArrayList;

public interface ArtistaModel extends UtenteModel {

    public void doSave(Artista artista); //aggiungere eccezioni
    public int doUpdate(Artista artista);
    public void doDelete(Artista artista);
    public Artista doRetrieveByKey(int idArtista);
    public ArrayList<Artista> doRetrieveAll(String order);
    public ArrayList<Evento> doRetrieveAllEventiArtista(int idArtista);
}
