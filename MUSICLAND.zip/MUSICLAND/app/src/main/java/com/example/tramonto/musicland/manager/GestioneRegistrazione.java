package com.example.tramonto.musicland.manager;

import com.example.tramonto.musicland.model.pojo.Artista;

import java.util.ArrayList;

public interface GestioneRegistrazione {

    public void registrazioneArtista(String email, String password, String nome,
                                     String cognome, String nickname, String sesso, int eta,
                                     String residenza, String cellulare, String linkSocial,
                                     String biografia, ArrayList<String> generiMusicali,
                                     ArrayList<String> strumentiMusicali, boolean isBand);

    public void registrazioneBand(String email, String password, String nomeBand,
                                  ArrayList<Artista> listaArtisti, String residenza,
                                  String cellulare, String linkSocial,
                                  String biografia, ArrayList<String> generiMusicali);

    public void registrazionePromotore(String email, String password, String nome,
                                       String cognome, String sesso, int eta,
                                       String residenza, String cellulare, String linkSocial,
                                       String biografia);

    public boolean verificaMail(String email);
}
