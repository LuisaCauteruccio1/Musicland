package com.example.tramonto.musicland.model.modelDAO;

import com.example.tramonto.musicland.model.interfaceDAO.InteressamentoModel;

public class InteressamentoModelDAO implements InteressamentoModel {
}
