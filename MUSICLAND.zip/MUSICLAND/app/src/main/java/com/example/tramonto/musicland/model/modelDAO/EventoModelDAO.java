package com.example.tramonto.musicland.model.modelDAO;

import com.example.tramonto.musicland.model.interfaceDAO.EventoModel;

public class EventoModelDAO implements EventoModel {
}
