package com.example.tramonto.musicland.manager;

import com.example.tramonto.musicland.model.pojo.Artista;
import com.example.tramonto.musicland.model.pojo.Band;
import com.example.tramonto.musicland.model.pojo.Evento;
import com.example.tramonto.musicland.model.pojo.Promotore;
import com.example.tramonto.musicland.model.pojo.PropostaEvento;
import com.example.tramonto.musicland.model.pojo.Utente;

import java.util.ArrayList;

public interface GestioneAccount {

    public boolean eliminaUtente(Utente utente);

    public Artista visualizzaProfiloArtista(Artista artista);

    public Band visualizzaProfiloBand(Band band);

    public Promotore visualizzaProfiloPromotore(Promotore promotore);

    public Artista modificaProfiloArtista(int idArtista);

    public Band modificaProfiloBand(String emailBand);

    public Promotore modificaProfiloPromotore(String emailPromotore);

    public ArrayList<PropostaEvento> visualizzaMieProposte(String emailPromotore);

    public ArrayList<Evento> visualizzaMieiEventi(String emailUtente);

    public ArrayList<Artista> cercaArtista(String filtro);

    public ArrayList<Band> cercaBand(String filtro);

    public ArrayList<Promotore> cercaPromotore();


}
