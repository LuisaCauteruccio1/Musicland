package com.example.tramonto.musicland.model.interfaceDAO;

import com.example.tramonto.musicland.model.pojo.Utente;

import java.sql.SQLException;
import java.util.ArrayList;

public interface UtenteModel {

    public void doSave(Utente utente); //aggiungere eccezioni
    public int doUpdate(Utente utente);
    public void doDelete(Utente utente);
    public Utente doRetrieveByKey(String emailUtente);
    public ArrayList<Utente> doRetrieveAll(String order);

}
