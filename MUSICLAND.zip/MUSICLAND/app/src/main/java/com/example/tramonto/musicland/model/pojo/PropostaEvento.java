package com.example.tramonto.musicland.model.pojo;

import java.util.ArrayList;
import java.util.GregorianCalendar;

public class PropostaEvento {

    public PropostaEvento(){

    }

    public int getIdPropostaEvento() {
        return idPropostaEvento;
    }

    public void setIdPropostaEvento(int idPropostaEvento) {
        this.idPropostaEvento = idPropostaEvento;
    }

    public String getNomePropostaEvento() {
        return nomePropostaEvento;
    }

    public void setNomePropostaEvento(String nomePropostaEvento) {
        this.nomePropostaEvento = nomePropostaEvento;
    }

    public GregorianCalendar getDataEvento() {
        return dataEvento;
    }

    public void setDataEvento(GregorianCalendar dataEvento) {
        this.dataEvento = dataEvento;
    }

    public GregorianCalendar getOrarioEvento() {
        return orarioEvento;
    }

    public void setOrarioEvento(GregorianCalendar orarioEvento) {
        this.orarioEvento = orarioEvento;
    }

    public Indirizzo getIndirizzo() {
        return indirizzo;
    }

    public void setIndirizzo(Indirizzo indirizzo) {
        this.indirizzo = indirizzo;
    }

    public String getNomeLocale() {
        return nomeLocale;
    }

    public void setNomeLocale(String nomeLocale) {
        this.nomeLocale = nomeLocale;
    }

    public ArrayList<String> getGeneriRichiesti() {
        return generiRichiesti;
    }

    public void setGeneriRichiesti(ArrayList<String> generiRichiesti) {
        this.generiRichiesti = generiRichiesti;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public String getEmailPromotore() {
        return emailPromotore;
    }

    public void setEmailPromotore(String emailPromotore) {
        this.emailPromotore = emailPromotore;
    }

    private int idPropostaEvento;
    private String nomePropostaEvento;
    private GregorianCalendar dataEvento;
    private GregorianCalendar orarioEvento;
    private Indirizzo indirizzo;
    private String nomeLocale;
    private ArrayList<String> generiRichiesti;
    private String descrizione;
    private String emailPromotore; //classe Promotore?
}
