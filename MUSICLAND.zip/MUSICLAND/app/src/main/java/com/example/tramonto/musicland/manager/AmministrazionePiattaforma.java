package com.example.tramonto.musicland.manager;

import android.util.EventLog;

import com.example.tramonto.musicland.model.pojo.Evento;
import com.example.tramonto.musicland.model.pojo.PropostaEvento;
import com.example.tramonto.musicland.model.pojo.Utente;

import java.util.ArrayList;

public interface AmministrazionePiattaforma {

    public ArrayList<Utente> visualizzaListaUtenti();

    public boolean eliminaUtente(Utente utente);

    public ArrayList<PropostaEvento> visualizzaListaProposteEvento();

    public boolean eliminaPropostaEventoUtente(PropostaEvento propostaEvento);

    public ArrayList<Evento> visualizzaListaEventi();

    public boolean eliminaEventoUtente(Evento evento);
}
