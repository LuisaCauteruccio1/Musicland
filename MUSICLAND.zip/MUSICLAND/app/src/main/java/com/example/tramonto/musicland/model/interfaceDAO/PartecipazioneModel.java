package com.example.tramonto.musicland.model.interfaceDAO;

import com.example.tramonto.musicland.model.pojo.Partecipazione;

import java.util.ArrayList;

public interface PartecipazioneModel {

    public void doSave(int idEvento, int idArtista);
    public void doSave(int idEvento, String emailBand);
    public void doDelete(int evento, int idArtista);
    public void doDelete(int evento, String emailBand);
    public Partecipazione doRetrieveByKey(int idEvento);
    public ArrayList<Partecipazione> doretrieveAll(String order);
}
