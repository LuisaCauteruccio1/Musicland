package com.example.tramonto.musicland.manager;

import com.example.tramonto.musicland.model.pojo.Utente;

public interface GestioneAutenticazione {

    public Utente login(String email, String password);
    // public AndroidHttpClient logout(Utente utente);
}
