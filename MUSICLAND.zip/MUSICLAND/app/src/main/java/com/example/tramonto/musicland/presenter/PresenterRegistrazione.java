package com.example.tramonto.musicland.presenter;

import com.example.tramonto.musicland.manager.GestioneRegistrazione;
import com.example.tramonto.musicland.model.pojo.Artista;

import java.util.ArrayList;

public class PresenterRegistrazione implements GestioneRegistrazione {
    @Override
    public void registrazioneArtista(String email, String password, String nome, String cognome, String nickname, String sesso, int eta, String residenza, String cellulare, String linkSocial, String biografia, ArrayList<String> generiMusicali, ArrayList<String> strumentiMusicali, boolean isBand) {

    }

    @Override
    public void registrazioneBand(String email, String password, String nomeBand, ArrayList<Artista> listaArtisti, String residenza, String cellulare, String linkSocial, String biografia, ArrayList<String> generiMusicali) {

    }

    @Override
    public void registrazionePromotore(String email, String password, String nome, String cognome, String sesso, int eta, String residenza, String cellulare, String linkSocial, String biografia) {

    }

    @Override
    public boolean verificaMail(String email) {
        return false;
    }
}
