package com.example.tramonto.musicland.model.interfaceDAO;

import com.example.tramonto.musicland.model.pojo.Artista;
import com.example.tramonto.musicland.model.pojo.Band;
import com.example.tramonto.musicland.model.pojo.Evento;
import com.example.tramonto.musicland.model.pojo.Utente;

import java.util.ArrayList;

public interface BandModel extends UtenteModel {

    public void doSave(Band band); //aggiungere eccezioni
    public int doUpdate(Band band);
    public void doDelete(Band band);
    public Band doRetrieveByKey(String emailBand);
    public ArrayList<Band> doRetrieveAll(String order);
    public ArrayList<Evento> doRetrieveAllEventiBand(String emailBand);
}
