package com.example.tramonto.musicland.presenter;

import com.example.tramonto.musicland.manager.GestioneEventi;
import com.example.tramonto.musicland.model.pojo.Artista;
import com.example.tramonto.musicland.model.pojo.Band;
import com.example.tramonto.musicland.model.pojo.Evento;
import com.example.tramonto.musicland.model.pojo.Indirizzo;
import com.example.tramonto.musicland.model.pojo.PropostaEvento;

import java.util.ArrayList;
import java.util.GregorianCalendar;

public class PresenterEventi implements GestioneEventi {
    @Override
    public void pubblicaEvento(PropostaEvento propostaEvento) {

    }

    @Override
    public void pubblicaEvento(String nomeLocale, String nomeSerata, GregorianCalendar data, GregorianCalendar orario, Indirizzo indirizzo, String descrizione, String emailPromotore, ArrayList<String> generiSuonati, ArrayList<Band> band, ArrayList<Artista> artisti) {

    }

    @Override
    public void pubblicaPropostaEvento(String nomeLocale, String nomeSerata, GregorianCalendar data, GregorianCalendar orario, Indirizzo indirizzo, String descrizione, String emailPromotore, ArrayList<String> generiRichiesti) {

    }

    @Override
    public PropostaEvento modificaPropostaEvento(int idPropostaEvento) {
        return null;
    }

    @Override
    public Evento modificaEvento(int idEvento) {
        return null;
    }

    @Override
    public boolean eliminaPropostaEvento(int idPropostaEvento) {
        return false;
    }

    @Override
    public boolean eliminaEvento(int idEvento) {
        return false;
    }

    @Override
    public ArrayList<PropostaEvento> cercaPropostaEvento(String filtro) {
        return null;
    }

    @Override
    public ArrayList<Evento> cercaEvento(String filtro) {
        return null;
    }
}
