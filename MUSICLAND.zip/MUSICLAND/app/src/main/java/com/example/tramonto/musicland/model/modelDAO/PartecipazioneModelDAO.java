package com.example.tramonto.musicland.model.modelDAO;

import com.example.tramonto.musicland.model.interfaceDAO.PartecipazioneModel;

public class PartecipazioneModelDAO implements PartecipazioneModel {
}
