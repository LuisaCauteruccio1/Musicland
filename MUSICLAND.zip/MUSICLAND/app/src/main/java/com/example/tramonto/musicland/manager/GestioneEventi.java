package com.example.tramonto.musicland.manager;

import com.example.tramonto.musicland.model.pojo.Artista;
import com.example.tramonto.musicland.model.pojo.Band;
import com.example.tramonto.musicland.model.pojo.Evento;
import com.example.tramonto.musicland.model.pojo.Indirizzo;
import com.example.tramonto.musicland.model.pojo.PropostaEvento;

import java.util.ArrayList;
import java.util.GregorianCalendar;

public interface GestioneEventi {

    public void pubblicaEvento(PropostaEvento propostaEvento);



    public void pubblicaEvento(String nomeLocale, String nomeSerata, GregorianCalendar data,
                               GregorianCalendar orario, Indirizzo indirizzo, String descrizione,
                               String emailPromotore, ArrayList<String> generiSuonati,
                               ArrayList<Band> band, ArrayList<Artista> artisti);

    public void pubblicaPropostaEvento(String nomeLocale, String nomeSerata, GregorianCalendar data,
                                       GregorianCalendar orario, Indirizzo indirizzo, String descrizione,
                                       String emailPromotore, ArrayList<String> generiRichiesti);

    public PropostaEvento modificaPropostaEvento(int idPropostaEvento);

    public Evento modificaEvento(int idEvento);

    public boolean eliminaPropostaEvento(int idPropostaEvento);

    public boolean eliminaEvento(int idEvento);

    public ArrayList<PropostaEvento> cercaPropostaEvento(String filtro);

    public ArrayList<Evento> cercaEvento(String filtro);

}
