package com.example.tramonto.musicland.model.modelDAO;

import com.example.tramonto.musicland.model.interfaceDAO.UtenteModel;

public class UtenteModelDAO implements UtenteModel {
}
