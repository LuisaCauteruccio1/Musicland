package com.example.tramonto.musicland.model.interfaceDAO;

import com.example.tramonto.musicland.model.pojo.Evento;

import java.util.ArrayList;

public interface EventoModel {

    public void doSave(Evento evento); //aggiungere eccezioni
    public int doUpdate(Evento evento);
    public void doDelete(Evento evento);
    public Evento doRetrieveByKey(int idEvento);
    public ArrayList<Evento> doRetrieveAll(String order);
}
