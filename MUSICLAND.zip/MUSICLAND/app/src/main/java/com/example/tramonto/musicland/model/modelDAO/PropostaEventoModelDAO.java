package com.example.tramonto.musicland.model.modelDAO;

import com.example.tramonto.musicland.model.interfaceDAO.PropostaEventoModel;

public class PropostaEventoModelDAO implements PropostaEventoModel {
}
