package com.example.tramonto.musicland.model.interfaceDAO;

import com.example.tramonto.musicland.model.pojo.Evento;
import com.example.tramonto.musicland.model.pojo.Promotore;
import com.example.tramonto.musicland.model.pojo.PropostaEvento;

import java.util.ArrayList;

public interface PromotoreModel extends UtenteModel {

    public void doSave(Promotore promotore); //aggiungere eccezioni
    public int doUpdate(Promotore promotore);
    public void doDelete(Promotore promotore);
    public Promotore doRetrieveByKey(String emailPromotore);
    public ArrayList<Promotore> doRetrieveAll(String order);
    public ArrayList<Evento> doRetrieveEventiPromotore(String emailPromotore);
    public ArrayList<PropostaEvento> doRetrieveProposteEventoPromotore(String emailPromotore);
}
