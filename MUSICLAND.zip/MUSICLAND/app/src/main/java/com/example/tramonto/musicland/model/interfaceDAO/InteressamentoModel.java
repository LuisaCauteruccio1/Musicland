package com.example.tramonto.musicland.model.interfaceDAO;

import com.example.tramonto.musicland.model.pojo.Interessamento;

import java.util.ArrayList;

public interface InteressamentoModel {

    public void doSave(int idPropostaEvento, int idArtista); //aggiungere eccezioni
    public void doSave(int idPropostaEvento, String emailBand);
    public void doDelete(int idPropostaEvento, int idArtista);
    public void doDelete(int idPropostaEvento, String emailBand);
    public Interessamento doRetrieveByKey(int idPropostaEvento);
    public ArrayList<Interessamento> doRetrieveAll(String order);


}
