package com.example.tramonto.musicland.presenter;

import com.example.tramonto.musicland.manager.GestioneAccount;
import com.example.tramonto.musicland.model.pojo.Artista;
import com.example.tramonto.musicland.model.pojo.Band;
import com.example.tramonto.musicland.model.pojo.Evento;
import com.example.tramonto.musicland.model.pojo.Promotore;
import com.example.tramonto.musicland.model.pojo.PropostaEvento;
import com.example.tramonto.musicland.model.pojo.Utente;

import java.util.ArrayList;

public class PresenterAccount implements GestioneAccount {
    @Override
    public boolean eliminaUtente(Utente utente) {
        return false;
    }

    @Override
    public Artista visualizzaProfiloArtista(Artista artista) {
        return null;
    }

    @Override
    public Band visualizzaProfiloBand(Band band) {
        return null;
    }

    @Override
    public Promotore visualizzaProfiloPromotore(Promotore promotore) {
        return null;
    }

    @Override
    public Artista modificaProfiloArtista(int idArtista) {
        return null;
    }

    @Override
    public Band modificaProfiloBand(String emailBand) {
        return null;
    }

    @Override
    public Promotore modificaProfiloPromotore(String emailPromotore) {
        return null;
    }

    @Override
    public ArrayList<PropostaEvento> visualizzaMieProposte(String emailPromotore) {
        return null;
    }

    @Override
    public ArrayList<Evento> visualizzaMieiEventi(String emailUtente) {
        return null;
    }

    @Override
    public ArrayList<Artista> cercaArtista(String filtro) {
        return null;
    }

    @Override
    public ArrayList<Band> cercaBand(String filtro) {
        return null;
    }

    @Override
    public ArrayList<Promotore> cercaPromotore() {
        return null;
    }
}
